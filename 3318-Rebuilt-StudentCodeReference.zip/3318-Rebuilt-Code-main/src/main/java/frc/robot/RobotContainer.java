package frc.robot;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.filter.SlewRateLimiter;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.RunCommand;
import edu.wpi.first.wpilibj2.command.button.CommandXboxController;
import edu.wpi.first.wpilibj2.command.button.Trigger;
import org.photonvision.PhotonCamera;

import frc.robot.subsystems.Intake;
import frc.robot.subsystems.Climber;
import frc.robot.subsystems.Feeder;
import frc.robot.subsystems.Shooter;
import frc.robot.subsystems.Swerve;
import frc.robot.subsystems.Hopper;

import frc.robot.Commands.SpinClimbMotor;
//import frc.robot.Commands.SpinIntakeArmMotor; Not Used
import frc.robot.Commands.SpinIntakeWheelMotor;
import frc.robot.Commands.SpinFeederMotor;
import frc.robot.Commands.SpinHopperMotor;
import frc.robot.Commands.AlignNShoot;
import frc.robot.Commands.MoveIntakeArmMotor;
import frc.robot.Commands.HomeIntakeArm;

//import frc.robot.subsystems.Shooter;

public class RobotContainer {
    public final CommandXboxController driver = new CommandXboxController(0);

    // private final int translationAxis = XboxController.Axis.kLeftY.value;
    // private final int strafeAxis = XboxController.Axis.kLeftX.value;
    // private final int rotationAxis = XboxController.Axis.kRightX.value ;

    // private final SlewRateLimiter translationLimiter = new SlewRateLimiter(5.0);
    // private final SlewRateLimiter strafeLimiter = new SlewRateLimiter(5.0);
    // private final SlewRateLimiter rotationLimiter = new SlewRateLimiter(5.0);
    // private final SlewRateLimiter shooterLimiter = new SlewRateLimiter(1.0);

    private final Climber climberSubsystem = new Climber();
    private final Intake intakeSubsystem = new Intake();
    private final Feeder feederSubsystem = new Feeder();
    private final Shooter shooterSubsystem = new Shooter();
    private final Swerve swerveSubsystem = new Swerve();
    private final Hopper hopperSubsystem = new Hopper();

    private static final PhotonCamera camera = new PhotonCamera("Camera");
    private HomeIntakeArm homeIntakeArm;

    public RobotContainer() {
        configureControllerButtons();
        new HomeIntakeArm(intakeSubsystem);
        //hopperSubsystem.setDefaultCommand(new SpinHopperMotor(hopperSubsystem, 0.3));
    }

    public void configureControllerButtons() {
        driver.a().whileTrue(new SpinClimbMotor(climberSubsystem, 0.5));
        driver.b().whileTrue(new SpinClimbMotor(climberSubsystem, -0.5));

        driver.x().onTrue(new MoveIntakeArmMotor(intakeSubsystem));
        driver.y().onTrue(new HomeIntakeArm(intakeSubsystem)); 

        driver.rightTrigger().toggleOnTrue(new SpinIntakeWheelMotor(intakeSubsystem, 0.8));
        driver.rightBumper().toggleOnTrue(new AlignNShoot(
            swerveSubsystem,
            shooterSubsystem,
            feederSubsystem,
            hopperSubsystem,
            camera
        ));



        // IMPORTANT - BELOW IS UNTESTED, PROP THE ROBOT UP AND TEST IT TO MAKE SURE
        // THAT IT WONT DRIVE INTO A WALL OR PERSON OUT OF CONTROL

        // if(false) //ADD PROPER TRIGGER FOR SHOOTING 
        // {
        //     swerveSubsystem.driveFaceHub(driver.getLeftX(),driver.getLeftY());
        // }
        // else
        // {
        //     swerveSubsystem.drive(driver.getLeftX(), driver.getLeftY(), driver.getRightX());
        // }
    }

    public static PhotonCamera getCamera() {
        return camera;
    }

    public HomeIntakeArm getHomeIntakeArm() {
        return homeIntakeArm;
    }

}
