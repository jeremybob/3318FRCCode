package frc.robot.Commands;

import frc.robot.subsystems.Swerve;
import frc.robot.subsystems.Shooter;
import frc.robot.subsystems.Feeder;
import frc.robot.subsystems.Hopper;

import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.DriverStation;
import frc.robot.Constants;

//for when we get camera figured out
import org.photonvision.PhotonCamera;
import org.photonvision.targeting.PhotonTrackedTarget;
import org.photonvision.targeting.PhotonPipelineResult;



public class AlignNShoot extends Command{
    private final Swerve swerve;
    private final Shooter shooter;
    private final Feeder feeder;
    private final Hopper hopper;

    private final PhotonCamera camera;

    private final double initialSpeed = 60;
    private double smoothedDistance = -1;
    private final double alpha = 0.3;

    Timer timer = new Timer();
    
    private enum State {
        SPIN_UP,  // wait for shooter wheels to reach speed
        CLEAR,    // brief reverse pulse on feeder
        ALIGN,    // rotate toward vision target
        FIRE
    }
    private State state;

    public AlignNShoot(Swerve swerve, Shooter shooter, Feeder feeder, Hopper hopper , PhotonCamera camera) {
        this.swerve = swerve;
        this.shooter = shooter;
        this.feeder = feeder;
        this.hopper = hopper;
        this.camera = camera;
        addRequirements(swerve, shooter, feeder, hopper);
    }

    @Override
    public void initialize() {
        timer.stop();
        timer.reset();
        state = State.SPIN_UP;
        shooter.setShooterSpeed(initialSpeed);
    }

    @Override
    public void execute() {
        switch (state){
            case SPIN_UP: {
                if (shooter.isAtSpeed(initialSpeed)) {
                    timer.stop();
                    timer.reset();
                    timer.start();
                    state = State.CLEAR;
                }
                break;
            }
            case CLEAR: {
                feeder.setFeederSpeed(-0.25);
                if(timer.hasElapsed(0.15)){
                    feeder.stop();
                    state = State.ALIGN;
                }
                break;
            }
            case ALIGN: {
                //rotate to face hub
                swerve.faceHub();

                //get distance from target and set shooter speed
                PhotonPipelineResult result = camera.getLatestResult();
                int[] hubTags = getAllianceHubTagIds();
                if (hubTags == null) {
                    //tell driver station bad
                    break;
                }
                PhotonTrackedTarget hubTarget = null;
                double bestArea = 0;
                if (result.hasTargets()) {
                    for (PhotonTrackedTarget target : result.getTargets()){
                        if (isHubTag(hubTags, target) && target.getArea() > bestArea) {
                            hubTarget = target;
                            bestArea = target.getArea();
                        }
                    }
                }
                if (hubTarget == null) {
                    this.cancel();
                    return;
                }

                double distance = 0;
                double speed = 0;
                if (hubTarget != null) {
                    double targetPitch = Math.toRadians(hubTarget.getPitch());
                    if (Math.abs(targetPitch) > 0.003) {
                        distance = (shooter.inch2met(Constants.HUB_HEIGHT) - shooter.inch2met(Constants.CAMERA_HEIGHT)) / Math.tan(targetPitch);
                    }

                    if (smoothedDistance < 0) smoothedDistance = distance;
                    smoothedDistance = alpha * distance + (1 - alpha) * smoothedDistance;
                    speed = shooter.RPM2RPS(shooter.getTheoreticalRPM(smoothedDistance));
                    shooter.setShooterSpeed(speed); //theoretical
                }
                
                //if reached target pose and target speed send signal to dashboard
                if (shooter.isAtSpeed(speed) && Math.abs(hubTarget.getYaw()) < 2) {
                    state = State.FIRE;
                }
                break;
            }

            case FIRE: {
                if (!timer.isRunning()){
                    timer.reset();
                    timer.start();
                }

                feeder.setFeederSpeed(Constants.FEED_POWER);
                hopper.setHopperSpeed(Constants.FEED_POWER);
                if (timer.hasElapsed(0.75)) {
                    feeder.setFeederSpeed(0);
                    hopper.setHopperSpeed(0.3);
                    state = State.ALIGN;
                    timer.stop();
                }
                break;
            }
            

        }
    }

    @Override
    public void end(boolean interrupted) {
        timer.stop();
        feeder.stop();
        shooter.stop();
        hopper.setHopperSpeed(0.3);
    }

    @Override
    public boolean isFinished() {
        return false;
    }

    private boolean isHubTag(int[] hubtags, PhotonTrackedTarget target) {
        for (int id : hubtags) {
            if (id == target.getFiducialId()) 
                return true;
        }
        return false;
    }

    private int[] getAllianceHubTagIds() {
        var alliance = DriverStation.getAlliance();
        if (alliance.isEmpty()) return null;
        return alliance.get() == DriverStation.Alliance.Red
                ? Constants.RED_HUB_TAG_IDS
                : Constants.BLUE_HUB_TAG_IDS;
    }
}
