package frc.robot.Commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.Intake;

public class SpinIntakeWheelMotor extends Command {

    private final Intake intakeSubsystem;
    private final double speed;

    public SpinIntakeWheelMotor(Intake intakeSubsystem, double speed) {
        this.intakeSubsystem = intakeSubsystem;
        this.speed = speed;
        addRequirements(this.intakeSubsystem);
    }

    @Override
    public void execute() {
        intakeSubsystem.setWheelSpeedPercentage(speed);
    }

    @Override
    public void end(boolean interrupted) {
        intakeSubsystem.stopWheel();
    }

    @Override
    public boolean isFinished() {
        return false;
    }
}