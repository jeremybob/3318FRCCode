package frc.robot.subsystems;

import com.revrobotics.PersistMode;
import com.revrobotics.ResetMode;
import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.config.SparkMaxConfig;
import com.revrobotics.spark.config.SparkBaseConfig.IdleMode;
import com.revrobotics.spark.SparkLowLevel.MotorType;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkClosedLoopController;

import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.controls.DutyCycleOut;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;

public class Intake extends SubsystemBase {
    private final SparkMax intakeArmMotor;
    private final TalonFX intakeWheelMotor;
    private final DutyCycleOut percentageSpeed = new DutyCycleOut(0);

    private final RelativeEncoder encoder;
    private final SparkClosedLoopController pidController;
    private static final double ARM_UP_POS = 0.0; //define home rotation
    private static final double ARM_DOWN_POS = 1.0; //define down position
    private SparkMaxConfig cSparkMaxConfig = new SparkMaxConfig();


    public Intake() {
        intakeArmMotor = new SparkMax(Constants.INTAKE_ARM_NEO_ID, MotorType.kBrushless); // neo
        encoder = intakeArmMotor.getEncoder();
        pidController = intakeArmMotor.getClosedLoopController();
        

        //these need tuning
        cSparkMaxConfig.closedLoop.pid(0.2,0,0);
        intakeArmMotor.configure(cSparkMaxConfig,ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);

        intakeWheelMotor = new TalonFX(Constants.INTAKE_WHEEL_KRAKEN_ID); // kraken
        SparkMaxConfig armConfig = new SparkMaxConfig();

        armConfig
                .smartCurrentLimit(40)
                .idleMode(IdleMode.kBrake)
                .inverted(false);
        intakeArmMotor.configure(
                armConfig,
                ResetMode.kResetSafeParameters,
                PersistMode.kPersistParameters);
    }

    // neo methods (arm)
    public void setArmSpeed(double speed) {
        intakeArmMotor.set(speed);
    }

    public void stop() {
        intakeArmMotor.stopMotor();
    }

    public boolean isArmUp(){
        double pos = encoder.getPosition();
        return pos >= ARM_UP_POS - 0.05 && pos <= ARM_UP_POS + 0.05;
    }

    public double getArmUpPos(){
        return ARM_UP_POS;
    }

    public double getArmDownPos(){
        return ARM_DOWN_POS;
    }

    public RelativeEncoder getEncoder(){
        return encoder;
    }

    public SparkClosedLoopController getPIDController(){
        return pidController;
    }

    // kraken methods (flywheel)
    public void setWheelSpeedPercentage(double speed) {
        intakeWheelMotor.setControl(percentageSpeed.withOutput(speed));
    }

    public void stopWheel() {
        intakeWheelMotor.setControl(percentageSpeed.withOutput(0));
    }
}

// kraken for rollers and neo for up and down