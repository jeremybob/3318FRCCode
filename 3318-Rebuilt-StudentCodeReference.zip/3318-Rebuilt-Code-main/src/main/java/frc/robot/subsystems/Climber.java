package frc.robot.subsystems;

import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.controls.DutyCycleOut;
import com.ctre.phoenix6.signals.NeutralModeValue;
import com.ctre.phoenix6.configs.TalonFXConfiguration;

//import edu.wpi.first.wpilibj.TalonFX;
//import edu.wpi.first.wpilibj.motorcontrol.PWMTalonFX;
//import edu.wpi.first.wpilibj.motorcontrol.MotorController;
//import edu.wpi.first.wpilibj.motorcontrol.PWMVictorSPX;  // Or any other motor controller, in case you use one alongside the TalonFX
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard; // For debugging and logging motor outputs
//import edu.wpi.first.wpilibj.Counter;  // If using encoders for feedback
//import edu.wpi.first.wpilibj.Encoder;  // If using an encoder for feedback

import frc.robot.Constants;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
// 1 kraken

public class Climber extends SubsystemBase {
    private final TalonFX climbMotor;
    private final DutyCycleOut percentageSpeed = new DutyCycleOut(0);

    public Climber() {
        climbMotor = new TalonFX(Constants.CLIMBER_KRAKEN_ID);
        //var config = new TalonFXConfiguration();

        //config.MotorOutput.NeutralMode = NeutralModeValue.Brake;

        //config.CurrentLimits.SupplyCurrentLimitEnable = true;
        //config.CurrentLimits.SupplyCurrentLimit = 40;
        //climbMotor.getConfigurator().apply(config);
    }

    public void setPercentageSpeed(double percentage) {
        climbMotor.setControl(percentageSpeed.withOutput(percentage));
    }

    public void stop() {
        climbMotor.setControl(percentageSpeed.withOutput(0));
        climbMotor.setNeutralMode(NeutralModeValue.Brake);
    }

}
