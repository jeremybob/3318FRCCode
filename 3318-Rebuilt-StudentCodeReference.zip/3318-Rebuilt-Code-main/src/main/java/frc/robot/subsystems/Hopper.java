package frc.robot.subsystems;

import com.revrobotics.PersistMode;
import com.revrobotics.ResetMode;
import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.config.SparkMaxConfig;
import com.revrobotics.spark.config.SparkBaseConfig.IdleMode;
import com.revrobotics.spark.SparkLowLevel.MotorType;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;

public class Hopper extends SubsystemBase {
    private final SparkMax hopperMotor;

    public Hopper() {
        hopperMotor = new SparkMax(Constants.HOPPER_NEO_ID, MotorType.kBrushless);

        SparkMaxConfig hopperConfig = new SparkMaxConfig();

        hopperConfig
                .smartCurrentLimit(40)
                .idleMode(IdleMode.kBrake)
                .inverted(false);

        hopperMotor.configure(
                hopperConfig,
                ResetMode.kResetSafeParameters,
                PersistMode.kPersistParameters);

    }

    public void setHopperSpeed(double speed) {
        hopperMotor.set(speed);
    }

    public void stop() {
        hopperMotor.stopMotor();
    }
}
