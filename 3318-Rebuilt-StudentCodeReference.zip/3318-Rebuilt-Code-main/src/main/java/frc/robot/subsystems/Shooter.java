package frc.robot.subsystems;

import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.controls.VelocityTorqueCurrentFOC;
import com.ctre.phoenix6.hardware.TalonFX;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;

public class Shooter extends SubsystemBase {
    private final TalonFX rightShooterMotor = new TalonFX(Constants.RIGHT_SHOOTER_KRAKEN_ID);
    private final TalonFX leftShooterMotor = new TalonFX(Constants.LEFT_SHOOTER_KRAKEN_ID);
    private final VelocityTorqueCurrentFOC shooterVelocityRequest = new VelocityTorqueCurrentFOC(0);

    public Shooter() {
        TalonFXConfiguration shooterConfig = new TalonFXConfiguration();
        
        shooterConfig.Slot0.kP = 0.12;
        shooterConfig.Slot0.kI = 0.0;
        shooterConfig.Slot0.kD = 0.0;

        shooterConfig.Slot0.kV = 0.12;
        shooterConfig.Slot0.kS = 0.2;
        shooterConfig.Slot0.kA = 0.0;

        rightShooterMotor.getConfigurator().apply(shooterConfig);
        leftShooterMotor.getConfigurator().apply(shooterConfig);
    }

    public void setShooterSpeed(double speed) { //SPEED IN RPS
        rightShooterMotor.setControl(shooterVelocityRequest.withVelocity(speed));
        leftShooterMotor.setControl(shooterVelocityRequest.withVelocity(speed));
    }

    public void stop() {
        rightShooterMotor.setControl(shooterVelocityRequest.withVelocity(0));
        leftShooterMotor.setControl(shooterVelocityRequest.withVelocity(0));
    }

    /**
     * Calculates the flywheel RPM with no slip/backspin and perfect transfer to
     * reach target
     * 
     * @see https://www.desmos.com/calculator/x4skexyoim for plotter, derivation
     *      from 2d kinematics
     * @param deltaDistance Horizontal Distance from shooter exit to hub aim point
     * 
     */
    public double getTheoreticalRPM(double deltaDistance) {
        final double distanceOffset = 0.0; // Increase to aim further than middle of hub
        final double hoodAngleRadians = deg2rad(65); // from horizontal
        final double deltaHeight = inch2met(Constants.HUB_HEIGHT) - inch2met(16);
        final double g = 9.81;
        final double flyWheelRadius = inch2met(4);

        double shootingDistance = deltaDistance + distanceOffset;

        double velocityTheoretical = (shootingDistance) / Math.cos(hoodAngleRadians) *
                Math.sqrt(
                        (-0.5 * g) / (deltaHeight - shootingDistance * Math.tan(hoodAngleRadians)));

        double RPMTheoretical = velocityTheoretical / flyWheelRadius * 30.0 / (Math.PI);

        return RPMTheoretical;
    }

    /**
     * Converts degrees to radians
     * 
     * @param degrees Input in degrees
     * @return Output in radians
     */
    private double deg2rad(double degrees) // degrees to radians
    {
        return degrees * Math.PI / 180;
    }

    /**
     * Converts inches to meters (1 Inch -> 0.0254 meters)
     * 
     * @param inches Input in inches
     * @return Output in Meters
     */
    public double inch2met(double inches) {
        return inches * 2.54 / 100.0;
    }

    //Congerts RPM to RPS
    public double RPM2RPS(double RPM) {
        return RPM / 2.0;
    }

    public boolean isAtSpeed(double targetRPS) {
        double leftRPS  = Math.abs(getLeftRPS());
        double rightRPS = Math.abs(getRightRPS());
        return Math.abs(leftRPS  - targetRPS) <= 1.5
            && Math.abs(rightRPS - targetRPS) <= 1.5;
    }

    public double getLeftRPS() {
        return leftShooterMotor.getVelocity().getValueAsDouble();
    }

    public double getRightRPS() {
        return rightShooterMotor.getVelocity().getValueAsDouble();
    }
}

// 1 kraken to shoot 1 neo to index for each shooter (2 shooters)