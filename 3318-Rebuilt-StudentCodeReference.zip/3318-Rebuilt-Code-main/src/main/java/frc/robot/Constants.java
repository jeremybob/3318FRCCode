package frc.robot;

import edu.wpi.first.apriltag.AprilTagFieldLayout;
import edu.wpi.first.apriltag.AprilTagFields;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.util.Units;


public final class Constants {
    // CAN Ids
    public static final int CLIMBER_KRAKEN_ID = 20; // fix port numbe
    public static final int INTAKE_ARM_NEO_ID = 14; // fix port number
    public static final int INTAKE_WHEEL_KRAKEN_ID = 15; // fix port number
    public static final int LEFT_SHOOTER_KRAKEN_ID = 16; // fix port number
    public static final int RIGHT_SHOOTER_KRAKEN_ID = 17; // fix port numbers
    public static final int FEEDER_SHOOTER_NEO_ID = 18; //fix port number
    public static final int HOPPER_NEO_ID = 19; //fix port number
    public static final int PIGEON = 13; //gyro

    // ---- Swerve drive motors & encoders ----
    // Each corner has 3 devices: Drive TalonFX, Steer TalonFX, CANcoder
    public static final int FRONT_LEFT_DRIVE    = 3;
    public static final int FRONT_LEFT_STEER    = 4;
    public static final int FRONT_LEFT_CANCODER = 10;

    public static final int FRONT_RIGHT_DRIVE    = 1;
    public static final int FRONT_RIGHT_STEER    = 2;
    public static final int FRONT_RIGHT_CANCODER = 10;
    
    public static final int FRONT_LEFT_DRIVE    = 3;
    public static final int FRONT_LEFT_STEER    = 4;
    public static final int FRONT_LEFT_CANCODER = 9;

    public static final int BACK_RIGHT_DRIVE    = 5;
    public static final int BACK_RIGHT_STEER    = 6;
    public static final int BACK_RIGHT_CANCODER = 11;

    public static final double CAMERA_HEIGHT = 12; //fix 
    public static final double HUB_HEIGHT = 72;
    public static final double FEED_POWER = 0.8;

    public static final Transform3d CAMERAPOSITION = new Transform3d(1, 1, 1, new Rotation3d(1,1,1));
     public static final AprilTagFieldLayout APRILTAGLAYOUT= AprilTagFieldLayout.loadField(AprilTagFields.kDefaultField);

    // ---- Alliance-specific HUB tag IDs for targeting ----
        // AlignAndShootCommand should ONLY aim at your alliance's HUB tags.
        // These are the z=1.124m (44.25in) tags mounted on each alliance's HUB.
        // Each HUB has 4 faces with 2 tags per face = 8 tags per HUB.
        // Red HUB center ≈ (11.92, 4.03), Blue HUB center ≈ (4.63, 4.03).
        public static final int[] RED_HUB_TAG_IDS  = {8, 9, 10, 11};
        public static final int[] BLUE_HUB_TAG_IDS = {24, 25, 26, 27};
      // ---- Physical dimensions ----
        // Robot frame is 27" × 27" (686mm × 686mm).
        // SDS MK4 modules: wheel center is approximately 2.625" inboard from the
        // outer frame rail. Track/wheelbase = 27" - 2 × 2.625" = 21.75" = 0.5525m.
        // Source: SDS MK4 module drawing — wheel center offset from mounting face.
        public static final double TRACK_WIDTH_M = Units.inchesToMeters(21.75);  // 0.5525 m

        // Distance between the FRONT and BACK wheel centers (meters)
        public static final double WHEEL_BASE_M = Units.inchesToMeters(21.75);   // 0.5525 m

        // ---- Wheel & gear math ----
        // 4-inch wheel = 0.1016 m diameter
        public static final double WHEEL_DIAMETER_M     = Units.inchesToMeters(4.0);
        public static final double WHEEL_CIRCUMFERENCE_M = Math.PI * WHEEL_DIAMETER_M; // ~0.319 m

        // MK4 L2 gear ratios from the SDS datasheet
        public static final double DRIVE_GEAR_RATIO = 6.75;  // motor turns per 1 wheel turn
        public static final double STEER_GEAR_RATIO = 12.8;  // motor turns per 1 wheel turn

        // ---- Speed limits ----
        // Falcon 500 free speed ≈ 6380 RPM = 106.33 RPS
        // Wheel free speed = 106.33 / 6.75 = 15.75 RPS
        // Max speed = 15.75 × 0.319 ≈ 5.02 m/s theoretical
        // We cap at 4.5 to leave headroom for battery sag.
        public static final double MAX_TRANSLATION_MPS = 4.5;   // m/s
        public static final double MAX_ROTATION_RADPS  = 10.0;  // rad/s

        // The maximum physical RPS the drive motor can spin (used for velocity commands)
        // Falcon 500 free speed = 6380 RPM = 106.33 RPS at 12V
        public static final double DRIVE_MOTOR_FREE_SPEED_RPS = 6380.0 / 60.0;

        // ---- Module wheel locations (relative to robot center) ----
        // WPILib uses +X = forward, +Y = left
        public static final Translation2d FRONT_LEFT_LOCATION  =
                new Translation2d( WHEEL_BASE_M / 2.0,  TRACK_WIDTH_M / 2.0);
        public static final Translation2d FRONT_RIGHT_LOCATION =
                new Translation2d( WHEEL_BASE_M / 2.0, -TRACK_WIDTH_M / 2.0);
        public static final Translation2d BACK_LEFT_LOCATION   =
                new Translation2d(-WHEEL_BASE_M / 2.0,  TRACK_WIDTH_M / 2.0);
        public static final Translation2d BACK_RIGHT_LOCATION  =
                new Translation2d(-WHEEL_BASE_M / 2.0, -TRACK_WIDTH_M / 2.0);

        // ---- CANcoder offsets (in ROTATIONS, -0.5 to +0.5) ----
        // HOW TO FIND THESE:
        //   1. Physically align all wheels pointing STRAIGHT FORWARD.
        //   2. Open Phoenix Tuner X → select each CANcoder.
        //   3. Read the "Absolute Position No Offset" signal.
        //   4. NEGATE that reading and enter it below.
        //      Example: if Tuner X shows 0.104, set -0.104 here.
        //
        // CALIBRATE BEFORE DRIVING! These MUST be set per-robot.
        // Use the "CalibrateCANcoders" auto in SmartDashboard to print current
        // raw readings — then negate and paste here.
        public static final double FL_CANCODER_OFFSET_ROT = 0.0;  // CALIBRATE ME
        public static final double FR_CANCODER_OFFSET_ROT = 0.0;  // CALIBRATE ME
        public static final double BL_CANCODER_OFFSET_ROT = 0.0;  // CALIBRATE ME
        public static final double BR_CANCODER_OFFSET_ROT = 0.0;  // CALIBRATE ME
}
